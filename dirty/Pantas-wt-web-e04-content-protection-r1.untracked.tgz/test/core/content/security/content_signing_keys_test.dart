import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';

void main() {
  test('content signing keyring decodes canonical Ed25519 public keys', () {
    final encoded = base64Encode(List<int>.generate(32, (index) => index));

    final key = ContentSigningKeys.lookup(
      ContentPackageManifest.signingKeyIdV1,
      publicKeysBase64ById: {
        ContentPackageManifest.signingKeyIdV1: encoded,
      },
    );

    expect(key, isNotNull);
    expect(key!.bytes, List<int>.generate(32, (index) => index));
    expect(ContentSigningKeys.lookup('unknown-signing-key'), isNull);
  });

  test('content signing keyring rejects malformed public key material', () {
    for (final encoded in <String>[
      'not-base64',
      base64Encode(List<int>.filled(31, 1)),
      '${base64Encode(List<int>.filled(32, 2))}\n',
    ]) {
      expect(
        () => ContentSigningKeys.lookup(
          ContentPackageManifest.signingKeyIdV1,
          publicKeysBase64ById: {
            ContentPackageManifest.signingKeyIdV1: encoded,
          },
        ),
        throwsFormatException,
      );
    }
  });
}
