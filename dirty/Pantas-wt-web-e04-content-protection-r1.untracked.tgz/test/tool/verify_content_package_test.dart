import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';

import '../../tools/build_content_package/build_content_package.dart';
import '../../tools/verify_content_package/verify_content_package.dart';

void main() {
  group('verifyContentPackageFiles', () {
    late Directory tempDir;
    late Uint8List bootstrapKey;
    late Uint8List signingSeed;
    late ContentPackageBuildResult package;
    late SimplePublicKey publicKey;

    setUp(() async {
      tempDir = Directory.systemTemp.createTempSync(
        'pantas_verify_content_package_test_',
      );
      bootstrapKey = Uint8List.fromList(
        List<int>.generate(32, (index) => index + 1),
      );
      signingSeed = Uint8List.fromList(
        List<int>.generate(32, (index) => 0xa0 + index),
      );
      package = await buildContentPackage(
        inputJson: File('test/fixtures/sanity/content_sample.json'),
        outputDirectory: Directory('${tempDir.path}/package'),
        bootstrapKey: bootstrapKey,
        signingPrivateKeySeed: signingSeed,
        versionFile: File('${tempDir.path}/content_seed_version.dart'),
      );
      final keyPair = await Ed25519().newKeyPairFromSeed(signingSeed);
      publicKey = await keyPair.extractPublicKey();
    });

    tearDown(() {
      if (tempDir.existsSync()) {
        tempDir.deleteSync(recursive: true);
      }
    });

    test('accepts exact package signed by a trusted fixture key', () async {
      final verified = await verifyContentPackageFiles(
        payload: package.payload,
        manifest: package.manifest,
        signature: package.signature,
        trustedPublicKeys: {
          ContentPackageManifest.signingKeyIdV1: publicKey,
        },
      );

      expect(verified.payloadSha256, package.manifestData.payloadSha256);
      expect(
        verified.sourceContentSha256,
        package.manifestData.sourceContentSha256,
      );
    });

    test('rejects a changed payload', () async {
      final bytes = package.payload.readAsBytesSync();
      package.payload.writeAsBytesSync(
        Uint8List.fromList(bytes)..[bytes.length - 1] >= 0x01,
      );

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1: publicKey,
          },
        ),
        throwsFormatException,
      );
    });

    test('rejects changed exact manifest bytes without a new signature',
        () async {
      final manifestText = package.manifest.readAsStringSync();
      expect(manifestText, contains('"releaseChannel":"prod"'));
      package.manifest.writeAsStringSync(
        manifestText.replaceFirst(
          '"releaseChannel":"prod"',
          '"releaseChannel":"dev"',
        ),
      );

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1: publicKey,
          },
        ),
        throwsFormatException,
      );
    });

    test('rejects a wrong trusted public key', () async {
      final wrongKeyPair = await Ed25519().newKeyPairFromSeed(
        Uint8List.fromList(List<int>.filled(32, 0x55)),
      );
      final wrongPublicKey = await wrongKeyPair.extractPublicKey();

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1: wrongPublicKey,
          },
        ),
        throwsFormatException,
      );
    });

    test('rejects an untrusted signing key id even when re-signed', () async {
      final untrustedManifest = _copyManifest(
        package.manifestData,
        signingKeyId: 'content-signing-untrusted',
      );
      await _replaceManifestAndSignature(
        package,
        untrustedManifest,
        signingSeed,
      );

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1: publicKey,
          },
        ),
        throwsFormatException,
      );
    });

    for (final incompatible in <ContentPackageManifest Function(
      ContentPackageManifest,
    )>[
      (manifest) => _copyManifest(
            manifest,
            applicationId: 'com.example.notpantas',
          ),
      (manifest) => _copyManifest(
            manifest,
            releaseChannel: 'staging',
         ),
      (manifest) => _copyManifest(
            manifest,
            contentSchemaVersion:
                ContentPackageManifest.contentSchemaV1 + 1,
        ),
    ]) {
      test('rejects a validly signed incompatible production manifest',
          () async {
        final badManifest = incompatible(package.manifestData);
        await _replaceManifestAndSignature(
          package,
          badManifest,
          signingSeed,
      );

        await expectLater(
          verifyContentPackageFiles(
            payload: package.payload,
            manifest: package.manifest,
            signature: package.signature,
            trustedPublicKeys: {
              ContentPackageManifest.signingKeyIdV1: publicKey,
            },
          ),
          throwsFormatException,
        );
      });
    }

    test('rejects a missing detached signature', () async {
      package.signature.deleteSync();

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1: publicKey,
          },
        ),
        throwsFormatException,
      );
    });

    test('rejects a malformed detached signature', () async {
      package.signature.writeAsBytesSync(List<int>.filled(63, 0x44));

      await expectLater(
        verifyContentPackageFiles(
          payload: package.payload,
          manifest: package.manifest,
          signature: package.signature,
          trustedPublicKeys: {
            ContentPackageManifest.signingKeyIdV1:) publicKey,
          },
        ),
        throwsFormatException,
      );
    });
  });
}

Future<void> _replaceManifestAndSignature(
  ContentPackageBuildResult package,
  ContentPackageManifest manifest,
  Uint8List signingSeed,
) async {
  final bytes = manifest.encode();
  final keyPair = await Ed25519().newKeyPairFromSeed(signingSeed);
  final signature = await Ed25519().sign(bytes, keyPair: keyPair);
  package.manifest.writeAsBytesSync(bytes);
  package.signature.writeAsBytesSync(signature.bytes);
}

ContentPackageManifest _copyManifest(
  ContentPackageManifest source, {
  String? applicationId,
  String? releaseChannel,
  int? contentSchemaVersion,
  String? signingKeyId,
}) {
  return ContentPackageManifest(
    formatVersion: source.formatVersion,
    applicationId: applicationId ?? source.applicationId,
    releaseChannel: releaseChannel ?? source.releaseChannel,
    payloadPath: source.payloadPath,
    sourceContentSha256: source.sourceContentSha256,
    payloadSha256: source.payloadSha256,
    contentSeedVersion: source.contentSeedVersion,
    contentSchemaVersion:
        contentSchemaVersion ?? source.contentSchemaVersion,
    readerSchemaMin: source.readerSchemaMin,
    readerSchemaMax: source.readerSchemaMax,
    cipherProfile: source.cipherProfile,
    bootstrapKeyId: source.bootstrapKeyId,
    signingKeyId: signingKeyId ?? source.signingKeyId,
  );
}
