import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';

import '../../tools/build_content_package/build_content_package.dart';
import '../../tools/verify_content_package/verify_content_package.dart';

void main() {
  group('protected content package verifier', () {
    late Directory tempDir;
    late Uint8List bootstrapKey;
    late Uint8List signingSeed;
    late SimplePublicKey publicKey;
    late ContentPackageBuildResult built;
    late File versionFile;

    setUpAll(() async {
      tempDir = Directory.systemTemp.createTempSync(
        'pantas_content_verifier_test_',
      );
      bootstrapKey = Uint8List.fromList(
        List<int>.generate(32, (index) => index + 1),
      );
      signingSeed = Uint8List.fromList(
        List<int>.generate(32, (index) => 0xb0 - index),
      );
      final keyPair = await Ed25519().newKeyPairFromSeed(signingSeed);
      publicKey = await keyPair.extractPublicKey();
      versionFile = File('${tempDir.path}/content_seed_version.dart');
      built = await buildContentPackage(
        inputJson: File('test/fixtures/sanity/content_sample.json'),
        outputDirectory: Directory('${tempDir.path}/package'),
        bootstrapKey: bootstrapKey,
        signingPrivateKeySeed: signingSeed,
        versionFile: versionFile,
      );
    });

    tearDownAll(() {
      if (tempDir.existsSync()) {
        tempDir.deleteSync(recursive: true);
      }
    });

    Map<String, String> fixtureKeyring() => {
          ContentPackageManifest.signingKeyIdV1: base64Encode(publicKey.bytes),
        };

    test('accepts exact signed protected package and source revision', () async {
      final verified = await verifyContentPackage(
        payload: built.payload,
        manifest: built.manifest,
        signature: built.signature,
        versionFile: versionFile,
        bootstrapKey: bootstrapKey,
        trustedSigningKeysBase64: fixtureKeyring(),
      );

      expect(verified.payloadSha256, built.manifestData.payloadSha256);
      expect(
        verified.sourceContentSha256,
        built.manifestData.sourceContentSha256,
      );
      expect(
        verified.contentSeedVersion,
        built.manifestData.contentSeedVersion,
      );
    });

    test('rejects reformatted manifest without a new signature', () async {
      final parsed = ContentPackageManifest.parse(
        built.manifest.readAsBytesSync(),
      );
      final reformatted = File('${tempDir.path}/reformatted.json')
        ..writeAsStringSync(
          '${const JsonEncoder.withIndent('  ').convert(parsed.toJson())}\n',
        );

      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: reformatted,
          signature: built.signature,
          versionFile: versionFile,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(isA<FormatException>()),
      );
    });

    test('rejects changed payload and detached signature', () async {
      final tamperedPayload = File('${tempDir.path}/tampered.db')
        ..writeAsBytesSync(built.payload.readAsBytesSync());
      final payloadBytes = tamperedPayload.readAsBytesSync();
      payloadBytes[payloadBytes.length - 1] ^= 0x01;
      tamperedPayload.writeAsBytesSync(payloadBytes);

      await expectLater(
        verifyContentPackage(
          payload: tamperedPayload,
          manifest: built.manifest,
          signature: built.signature,
          versionFile: versionFile,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(isA<FormatException>()),
      );

      final tamperedSignature = File('${tempDir.path}/tampered.sig')
        ..writeAsBytesSync(built.signature.readAsBytesSync());
      final signatureBytes = tamperedSignature.readAsBytesSync();
      signatureBytes[0] ^= 0x01;
      tamperedSignature.writeAsBytesSync(signatureBytes);

      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: built.manifest,
          signature: tamperedSignature,
          versionFile: versionFile,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(isA<FormatException>()),
      );
    });

    test('rejects wrong bootstrap key and untrusted signing key', () async {
      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: built.manifest,
          signature: built.signature,
          versionFile: versionFile,
          bootstrapKey: Uint8List.fromList(List<int>.filled(32, 0x55)),
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(anything),
      );

      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: built.manifest,
          signature: built.signature,
          versionFile: versionFile,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: const {},
        ),
        throwsA(isA<FormatException>()),
      );
    });

    test('rejects signed incompatible manifest and source-version mismatch', () async {
      final original = ContentPackageManifest.parse(
        built.manifest.readAsBytesSync(),
      );
      final incompatible = ContentPackageManifest(
        formatVersion: original.formatVersion,
        applicationId: 'com.example.not-pantas',
        releaseChannel: original.releaseChannel,
        payloadPath: original.payloadPath,
        sourceContentSha256: original.sourceContentSha256,
        payloadSha256: original.payloadSha256,
        contentSeedVersion: original.contentSeedVersion,
        contentSchemaVersion: original.contentSchemaVersion,
        readerSchemaMin: original.readerSchemaMin,
        readerSchemaMax: original.readerSchemaMax,
        cipherProfile: original.cipherProfile,
        bootstrapKeyId: original.bootstrapKeyId,
        signingKeyId: original.signingKeyId,
      );
      final incompatibleBytes = incompatible.encode();
      final incompatibleManifest = File('${tempDir.path}/incompatible.json')
        ..writeAsBytesSync(incompatibleBytes);
      final keyPair = await Ed25519().newKeyPairFromSeed(signingSeed);
      final resigned = await Ed25519().sign(incompatibleBytes, keyPair: keyPair);
      final incompatibleSignature = File('${tempDir.path}/incompatible.sig')
        ..writeAsBytesSync(resigned.bytes);

      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: incompatibleManifest,
          signature: incompatibleSignature,
          versionFile: versionFile,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(isA<FormatException>()),
      );

      final mismatchedVersion = File('${tempDir.path}/wrong_version.dart')
        ..writeAsStringSync(
          "const contentSeedVersion = '0000000000000000';\n",
        );
      await expectLater(
        verifyContentPackage(
          payload: built.payload,
          manifest: built.manifest,
          signature: built.signature,
          versionFile: mismatchedVersion,
          bootstrapKey: bootstrapKey,
          trustedSigningKeysBase64: fixtureKeyring(),
        ),
        throwsA(isA<FormatException>()),
      );
    });
  });
}
