import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';

void main() {
  test('release preflight authorizes only the signed protected package', () {
    final release =
        File('tools/release/android/release.sh').readAsStringSync();

    expect(release, isNot(contains('APPROVED_CONTENT_DB_SHA256')));
    expect(release, isNot(contains('approved_content_sha')));
    expect(release, isNot(contains('actual_content_sha')));
    expect(release, isNot(contains('tracked_content_prefix')));

    expect(release, contains('assets/seed/content.db'));
    expect(release, contains('assets/seed/content.manifest.json'));
    expect(release, contains('assets/seed/content.manifest.sig'));
    expect(
      release,
      contains('tools/verify_content_package/verify_content_package.dart'),
    );
    expect(
      release,
      contains('require_env PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64'),
    );
    expect(
      release,
      contains('--dart-define=PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64='),
    );
    expect(
      release,
      contains('|| fail "protected content package verification failed"'),
    );
  });

  test('release verifier fails closed until production public key is provisioned',
      () {
    expect(
      ContentSigningKeys.lookup(ContentPackageManifest.signingKeyIdV1),
      isNull,
      reason:
          'authorized content-signing-v1 public key has not been provisioned',
    );

    final release =
        File('tools/release/android/release.sh').readAsStringSync();
    expect(
      release,
      contains('tools/verify_content_package/verify_content_package.dart'),
    );
    expect(
      release,
      contains('|| fail "protected content package verification failed"'),
    );
  });
}
