import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as hashes;
import 'package:cryptography/cryptography.dart';
import 'package:pantas/core/content/security/content_cipher_profile.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';

Future<void> main(List<String> args) async {
  if (args.length != 4) {
    stderr.writeln(
      'usage: dart run tools/verify_content_package/verify_content_package.dart '
      '<content.db> <content.manifest.json> <content.manifest.sig> '
      '<content_seed_version.dart>',
    );
    exitCode = 64;
    return;
  }

  try {
    final secrets = ContentPackageVerificationSecrets.fromEnvironment(
      Platform.environment,
    );
    final verified = await verifyContentPackage(
      payload: File(args[0]),
      manifest: File(args[1]),
      signature: File(args[2]),
      versionFile: File(args[3]),
      bootstrapKey: secrets.bootstrapKey,
    );
    stdout.writeln(
      'Verified protected content package '
      '${verified.contentSeedVersion}.',
    );
  } on Object catch (error) {
    stderr.writeln('content package verification failed: $error');
    exitCode = 65;
  }
}

final class ContentPackageVerificationSecrets {
  ContentPackageVerificationSecrets._(this.bootstrapKey);

  factory ContentPackageVerificationSecrets.fromEnvironment(
    Map<String, String> environment,
  ) {
    const name = 'PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64';
    final encoded = environment[name];
    if (encoded == null || encoded.isEmpty) {
      throw const FormatException(
        'required environment variable PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64 '
        'is missing',
      );
    }

    final List<int> decoded;
    try {
      decoded = base64Decode(encoded);
    } on FormatException {
      throw const FormatException(
        'PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64 must be canonical base64',
      );
    }
    if (decoded.length != 32 || base64Encode(decoded) != encoded) {
      throw const FormatException(
        'PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64 must encode exactly 32 bytes',
      );
    }
    return ContentPackageVerificationSecrets._(Uint8List.fromList(decoded));
  }

  final Uint8List bootstrapKey;
}

final class ContentPackageVerificationResult {
  const ContentPackageVerificationResult(this.manifest);

  final ContentPackageManifest manifest;

  String get sourceContentSha256 => manifest.sourceContentSha256;
  String get payloadSha256 => manifest.payloadSha256;
  String get contentSeedVersion => manifest.contentSeedVersion;
}

Future<ContentPackageVerificationResult> verifyContentPackage({
  required File payload,
  required File manifest,
  required File signature,
  required File versionFile,
  required Uint8List bootstrapKey,
  Map<String, String>? trustedSigningKeysBase64,
}) async {
  if (bootstrapKey.length != 32) {
    throw const FormatException('content bootstrap key must be 32 bytes');
  }

  final manifestBytes = await manifest.readAsBytes();
  final parsed = ContentPackageManifest.parse(manifestBytes);
  final publicKey = ContentSigningKeys.lookup(
    parsed.signingKeyId,
    publicKeysBase64ById: trustedSigningKeysBase64,
  );
  if (publicKey == null) {
    throw FormatException(
      'untrusted content signing key id: ${parsed.signingKeyId}',
    );
  }

  final signatureBytes = await signature.readAsBytes();
  if (signatureBytes.length != 64) {
    throw const FormatException('invalid Ed25519 content signature length');
  }
  final validSignature = await Ed25519().verify(
    manifestBytes,
    signature: Signature(signatureBytes, publicKey: publicKey),
  );
  if (!validSignature) {
    throw const FormatException('invalid protected content manifest signature');
  }

  parsed.validateProduction();

  final payloadSha256 = hashes.sha256
      .convert(await payload.readAsBytes())
      .toString();
  if (payloadSha256 != parsed.payloadSha256) {
    throw const FormatException('protected content payload digest mismatch');
  }

  final trackedVersion = _readTrackedContentSeedVersion(versionFile);
  if (trackedVersion != parsed.contentSeedVersion) {
    throw const FormatException('protected content source revision mismatch');
  }

  final keyed = ContentCipherProfile.open(payload, bootstrapKey);
  keyed.dispose();

  return ContentPackageVerificationResult(parsed);
}

String _readTrackedContentSeedVersion(File versionFile) {
  final source = versionFile.readAsStringSync();
  final match = RegExp(
    r"^const contentSeedVersion = '([0-9a-f]{16})';$",
    multiLine: true,
  ).firstMatch(source);
  if (match == null) {
    throw const FormatException(
      'tracked content seed version is missing or malformed',
    );
  }
  return match.group(1)!;
}
