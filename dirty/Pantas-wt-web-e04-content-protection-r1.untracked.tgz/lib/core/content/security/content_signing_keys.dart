import 'dart:convert';

import 'package:cryptography/cryptography.dart';

/// Trusted Ed25519 verification keys for protected content packages.
///
/// Only public verification material belongs here. The production
/// `content-signing-v1` entry must be provisioned from the authorized durable
/// publisher key; this implementation deliberately does not invent one.
abstract final class ContentSigningKeys {
  static const publicKeysBase64ById = <String, String>{};

  static SimplePublicKey? lookup(
    String keyId, {
    Map<String, String>? publicKeysBase64ById,
  }) {
    final keyring =
        publicKeysBase64ById ?? ContentSigningKeys.publicKeysBase64ById;
    final encoded = keyring[keyId];
    if (encoded == null) return null;

    final List<int> decoded;
    try {
      decoded = base64Decode(encoded);
    } on FormatException {
      throw FormatException('invalid Ed25519 public key for $keyId');
    }
    if (decoded.length != 32 || base64Encode(decoded) != encoded) {
      throw FormatException('invalid Ed25519 public key for $keyId');
    }

    return SimplePublicKey(decoded, type: KeyPairType.ed25519);
  }
}
