import json, re, glob, os

strategy = {}
with open('docs/content/illustrations/strategy.tsv') as f:
    for line in f:
        parts = line.strip('\n').split('\t')
        if len(parts) >= 8:
            key = f"{parts[0]}/{parts[1]}/{parts[2]}#{parts[3]}"
            strategy[key] = parts[5]

added_figures = []
for file in sorted(glob.glob('content/lessons/reasoning/**/*.md', recursive=True)):
    with open(file) as f:
        content = f.read()
    
    seq = 1
    for i, line in enumerate(content.split('\n')):
        m = re.search(r'<!-- FIGURE: (\{.*\}) -->', line)
        if m:
            spec = json.loads(m.group(1))
            parts = file.replace('.md', '').split('/')
            key = f"reasoning/{parts[-2]}/{parts[-1]}#{seq}"
            added_figures.append({
                'file': file,
                'line': i + 1,
                'spec': spec,
                'desc': strategy.get(key, 'MISSING')
            })
            seq += 1

with open('w4_summary.txt', 'w') as out:
    for i, fig in enumerate(added_figures):
        if 'spring' in fig['file'] or 'stability' in fig['file']:
            out.write(f"--- Fig {i+1}: {os.path.basename(fig['file'])}:{fig['line']} ---\n")
            out.write(f"Desc: {fig['desc']}\n")
            out.write(f"Spec: {json.dumps(fig['spec'])}\n\n")
