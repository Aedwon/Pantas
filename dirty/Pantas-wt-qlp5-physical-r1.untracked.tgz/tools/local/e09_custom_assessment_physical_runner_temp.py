from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

PRESERVED_PACKAGES = (
    "com.aedwon.pantas.dev.staging",
    "com.aedwon.pantas.dev",
    "com.aedwon.pantas.dev.qlp5",
    "com.aedwon.pantas.dev.e09fresh",
)


def run(argv: list[str], *, env: dict[str, str], timeout: int = 120) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(
        argv,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        env=env,
    )
    print("$ " + " ".join(argv))
    print((proc.stdout or "")[-24000:])
    print(f"exit={proc.returncode}")
    return proc


def require_device(serial: str, env: dict[str, str]) -> None:
    run(["adb", "connect", serial], env=env, timeout=30)
    state = run(["adb", "-s", serial, "get-state"], env=env, timeout=30)
    if state.returncode != 0 or state.stdout.strip() != "device":
        raise SystemExit("device unavailable")


def require_preserved_packages(serial: str, env: dict[str, str], phase: str) -> None:
    for package in PRESERVED_PACKAGES:
        result = run(
            ["adb", "-s", serial, "shell", "pm", "path", package],
            env=env,
            timeout=30,
        )
        if result.returncode != 0 or "package:" not in result.stdout:
            raise SystemExit(f"preserved package missing {phase}: {package}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", required=True)
    parser.add_argument("--bootstrap-key-file", required=True)
    args = parser.parse_args()

    env = os.environ.copy()
    env["ADB_MDNS_AUTO_CONNECT"] = "0"

    require_device(args.device, env)
    require_preserved_packages(args.device, env, "before test")

    encoded = Path(args.bootstrap_key_file).read_text().strip()
    decoded = base64.b64decode(encoded, validate=True)
    if len(decoded) != 32:
        raise SystemExit("bootstrap key invalid")

    fd, temp_path = tempfile.mkstemp(prefix="pantas-e09verify-", suffix=".json")
    os.close(fd)
    os.chmod(temp_path, 0o600)
    try:
        Path(temp_path).write_text(
            json.dumps({"PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64": encoded})
        )
        proc = subprocess.run(
            [
                "flutter",
                "test",
                "integration_test/release/e09_custom_assessment_physical_temp.dart",
                "-d",
                args.device,
                "--flavor",
                "e09verify",
                f"--dart-define-from-file={temp_path}",
                "--no-pub",
                "--reporter",
                "expanded",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=3000,
            env=env,
        )
        print("\n".join((proc.stdout or "").splitlines()[-500:]))
        print(f"physical_test_exit={proc.returncode}")
        if proc.returncode != 0:
            return proc.returncode
    finally:
        Path(temp_path).unlink(missing_ok=True)

    require_preserved_packages(args.device, env, "after test")
    print("E09_CUSTOM_ASSESSMENT_PHYSICAL_RUN=PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
