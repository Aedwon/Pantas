from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap-key-file", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    encoded = Path(args.bootstrap_key_file).read_text().strip()
    decoded = base64.b64decode(encoded, validate=True)
    if len(decoded) != 32:
        raise SystemExit("bootstrap key invalid")

    fd, temp_path = tempfile.mkstemp(prefix="pantas-qlp5-profile-", suffix=".json")
    os.close(fd)
    os.chmod(temp_path, 0o600)
    try:
        Path(temp_path).write_text(
            json.dumps({"PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64": encoded})
        )
        proc = subprocess.run(
            [
                "flutter",
                "build",
                "apk",
                "--profile",
                "--flavor",
                "qlp5",
                "-t",
                "integration_test/release/qlp5_physical_benchmark_temp.dart",
                f"--dart-define-from-file={temp_path}",
                "--no-pub",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=3000,
        )
        safe = [
            line
            for line in (proc.stdout or "").splitlines()
            if "PANTAS_CONTENT_BOOTSTRAP_KEY" not in line
        ]
        print("\n".join(safe[-250:]))
        print(f"build_exit={proc.returncode}")
        if proc.returncode != 0:
            return proc.returncode
    finally:
        Path(temp_path).unlink(missing_ok=True)

    src = Path("build/app/outputs/flutter-apk/app-qlp5-profile.apk")
    if not src.is_file():
        raise SystemExit("expected qlp5 profile APK missing")
    dst = Path(args.output)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"apk_sha256={hashlib.sha256(dst.read_bytes()).hexdigest()}")
    print(f"apk_size={dst.stat().st_size}")
    print("QLP5_PROFILE_TARGET_BUILD=PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
