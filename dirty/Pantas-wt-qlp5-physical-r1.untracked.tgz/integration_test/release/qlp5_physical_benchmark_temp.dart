import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/core/auth/auth_state.dart';
import 'package:pantas/core/auth/providers.dart';
import 'package:pantas/core/content/bundle/protected_content_installer.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/content/security/content_package_verifier.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';
import 'package:pantas/core/storage/data/repos/assessment_repository.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:pantas/core/storage/data/repos/quiz_nudge_repository.dart';
import 'package:pantas/core/storage/storage.dart';
import 'package:pantas/core/ui/components/answer_row.dart';
import 'package:pantas/core/ui/theme/app_theme.dart';
import 'package:pantas/features/paywall/paywall.dart';
import 'package:pantas/features/quiz/application/quiz_launch_coordinator.dart';
import 'package:pantas/features/quiz/application/quiz_performance_probe.dart';
import 'package:pantas/features/quiz/application/today_quiz_preparer.dart';
import 'package:pantas/features/quiz/domain/models/quiz_ordering.dart';
import 'package:pantas/features/quiz/domain/models/quiz_preferences.dart';
import 'package:pantas/features/quiz/domain/models/session_origin.dart';
import 'package:pantas/features/quiz/presentation/quiz_controller.dart';
import 'package:pantas/features/quiz/presentation/quiz_page.dart';

import 'support/qlp5_performance_collector.dart';
import 'support/release_harness.dart';

const _keyId = 'content-bootstrap-v1';
const _keyB64 = String.fromEnvironment('PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64');
const _samples = 30;
final _fixedNow = DateTime(2026, 9, 15, 14);

Future<Uint8List> _load(String path) async {
  final data = await rootBundle.load(path);
  return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
}

ContentBootstrapKeyEntry? _bootstrap(String keyId) {
  if (keyId != _keyId || _keyB64.isEmpty) return null;
  final bytes = base64Decode(_keyB64);
  if (bytes.length != 32) return null;
  return ContentBootstrapKeyEntry(
    keyId: _keyId,
    keyBytes: Uint8List.fromList(bytes),
    sequenceWindow: const ContentSequenceWindow(minReleaseSequence: 1),
  );
}

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('E09 QLP5 physical core ordinary scenarios', (tester) async {
    final previousFlutterErrorHandler = FlutterError.onError;
    FlutterError.onError = (details) {
      final payload = jsonEncode(<String, Object?>{
        'exception': details.exceptionAsString(),
        'stack': details.stack?.toString(),
        'library': details.library,
        'context': details.context?.toDescription(),
      });
      debugPrintSynchronously('E09_QLP5_CAPTURED_FLUTTER_ERROR=$payload');
      previousFlutterErrorHandler?.call(details);
    };
    addTearDown(() {
      FlutterError.onError = previousFlutterErrorHandler;
    });

    debugPrintSynchronously('E09_QLP5_STAGE=protected_content_install_start');
    final install = await ensureProtectedContentInstalled(
      verifier: const BundledContentPackageVerifier(
        loadAssetBytes: _load,
        signingKeyLookup: ContentSigningKeys.lookupEntry,
        bootstrapKeyLookup: _bootstrap,
      ),
    );

    debugPrintSynchronously('E09_QLP5_STAGE=protected_content_install_done');
    final collector = Qlp5PerformanceCollector();
    var queryCount = 0;
    final queryWindows = <String, List<int>>{};

    final harness = ReleaseHarness(
      additionalOverrides: <Override>[
        authStateProvider.overrideWith(
          (_) => Stream.value(
            const AuthState.anonymous(uid: 'qlp5-physical'),
          ),
        ),
        entitlementProvider.overrideWith(
          (_) => Stream.value(const Entitlement.free()),
        ),
        nowProvider.overrideWithValue(() => _fixedNow),
        quizPerformanceProbeProvider.overrideWithValue(
          QuizPerformanceProbe.recording(collector.recordPhaseSample),
        ),
        contentRepositoryProvider.overrideWith(
          (ref) => ContentRepository(
            ref.watch(contentDatabaseProvider),
            onQuery: () => queryCount += 1,
          ),
        ),
      ],
    );
    debugPrintSynchronously('E09_QLP5_STAGE=harness_open_databases_start');
    await harness.openDatabases();
    addTearDown(harness.dispose);
    debugPrintSynchronously('E09_QLP5_STAGE=harness_reset_start');
    await _resetDisposableState(harness);
    debugPrintSynchronously('E09_QLP5_STAGE=harness_reset_done');

    final content = harness.providerContainer.read(contentRepositoryProvider);
    final exams = await content.listExams();
    expect(exams, isNotEmpty);

    String? examId;
    var richestCount = -1;
    for (final exam in exams.where((exam) => !exam.isCustom)) {
      final examRows = await content.selectionRowsByExam(exam.id);
      final name = '${exam.name} ${exam.shortName}'.toUpperCase();
      if (name.contains('UPCAT') && examRows.length >= 20) {
        examId = exam.id;
        break;
      }
      if (examRows.length > richestCount) {
        richestCount = examRows.length;
        examId = exam.id;
      }
    }
    expect(examId, isNotNull);
    final selectedExamId = examId!;

    final rows = await content.selectionRowsByExam(selectedExamId);
    expect(rows.length, greaterThanOrEqualTo(20));
    final topics = await content.topicsByExam(selectedExamId);
    expect(topics, isNotEmpty);

    final prefs =
        harness.providerContainer.read(appPreferencesRepositoryProvider);
    await prefs.setPassedAgeGate(value: true);
    await prefs.setSelectedExamId(selectedExamId);
    await prefs.setCompletedOnboarding(value: true);

    await harness.providerContainer
        .read(assessmentRepositoryProvider)
        .saveResult(
      selectedExamId,
      _fixedNow,
      <TopicScore>[
        for (final topic in topics)
          TopicScore(topicId: topic.id, correct: 1, total: 1),
      ],
    );
    await QuizNudgeRepository(harness.appDatabase).markDismissed();

    final quizPrefs =
        harness.providerContainer.read(quizPreferencesRepositoryProvider);
    await quizPrefs.save(
      QuizPreferences(
        sessionLength: 20,
        ordering: QuizOrdering.blocked,
        newCardCap: 20,
      ),
    );

    final request = QuizPreparationRequest(
      userId: quizLocalUserId,
      examId: selectedExamId,
    );
    final preparer = harness.providerContainer.read(todayQuizPreparerProvider);
    final sessions =
        harness.providerContainer.read(quizSessionRepositoryProvider);
    final coordinator =
        harness.providerContainer.read(quizLaunchCoordinatorProvider);

    debugPrintSynchronously('E09_QLP5_STAGE=first_recommendation_start');
    for (var i = 0; i < _samples; i++) {
      preparer.invalidate(request);
      queryCount = 0;
      final watch = Stopwatch()..start();
      final prepared = await preparer.prepare(request);
      watch.stop();
      expect(prepared.plan.questions, isNotEmpty);
      collector.recordObservation(
        Qlp5Metric.firstRecommendation,
        watch.elapsed,
        temperature: Qlp5RunTemperature.cold,
      );
      (queryWindows['first_recommendation'] ??= <int>[]).add(queryCount);
    }

    debugPrintSynchronously('E09_QLP5_STAGE=first_recommendation_done');
    final cached = await preparer.prepare(request);
    expect(cached.plan.questions, isNotEmpty);
    debugPrintSynchronously('E09_QLP5_STAGE=unchanged_recommendation_start');
    for (var i = 0; i < _samples; i++) {
      queryCount = 0;
      final watch = Stopwatch()..start();
      final again = await preparer.prepare(request);
      watch.stop();
      expect(identical(again, cached), isTrue);
      collector.recordObservation(
        Qlp5Metric.unchangedRecommendationFrame,
        watch.elapsed,
        temperature: Qlp5RunTemperature.warm,
      );
      (queryWindows['unchanged_recommendation'] ??= <int>[]).add(queryCount);
    }

    debugPrintSynchronously('E09_QLP5_STAGE=unchanged_recommendation_done');
    debugPrintSynchronously('E09_QLP5_STAGE=warm_start_start');
    for (var i = 0; i < _samples; i++) {
      await sessions.quitAllOpen(
        userId: quizLocalUserId,
        examId: selectedExamId,
        quitAt: _fixedNow.add(Duration(seconds: i)),
      );
      coordinator.clearCommitted(request);
      final prepared = await preparer.prepare(request);
      queryCount = 0;
      final watch = Stopwatch()..start();
      final result = await coordinator.launchToday(request, prepared: prepared);
      watch.stop();
      expect(result, isA<QuizLaunchStarted>());
      collector.recordObservation(
        Qlp5Metric.warmStart,
        watch.elapsed,
        temperature: Qlp5RunTemperature.warm,
      );
      (queryWindows['warm_start'] ??= <int>[]).add(queryCount);
    }
    debugPrintSynchronously('E09_QLP5_STAGE=warm_start_done');
    await sessions.quitAllOpen(
      userId: quizLocalUserId,
      examId: selectedExamId,
      quitAt: _fixedNow.add(const Duration(minutes: 1)),
    );
    coordinator.clearCommitted(request);

    debugPrintSynchronously('E09_QLP5_STAGE=resume_metrics_start');
    for (final length in <int>[5, 10, 20]) {
      await sessions.create(
        sessionId: 'qlp5-resume-$length',
        userId: quizLocalUserId,
        examId: selectedExamId,
        origin: SessionOrigin.todayTopic,
        questionIds: [for (final row in rows.take(length)) row.id],
        startedAt: _fixedNow,
        topicId: rows.first.topicId,
      );
      coordinator.clearCommitted(request);
      for (var i = 0; i < _samples; i++) {
        queryCount = 0;
        final watch = Stopwatch()..start();
        final session = await coordinator.resumeToday(request);
        watch.stop();
        expect(session, isNotNull);
        expect(session!.questions.length, length);
        collector.recordObservation(
          switch (length) {
            5 => Qlp5Metric.resume5,
            10 => Qlp5Metric.resume10,
            _ => Qlp5Metric.resume20,
          },
          watch.elapsed,
          temperature: Qlp5RunTemperature.warm,
        );
        (queryWindows['resume_$length'] ??= <int>[]).add(queryCount);
      }
      await sessions.quitAllOpen(
        userId: quizLocalUserId,
        examId: selectedExamId,
        quitAt: _fixedNow.add(Duration(minutes: length)),
      );
      coordinator.clearCommitted(request);
    }

    debugPrintSynchronously('E09_QLP5_STAGE=resume_metrics_done');
    debugPrintSynchronously('E09_QLP5_STAGE=prepared_next_setup_start');
    final preparedForNext = await preparer.prepare(request);
    final startResult =
        await coordinator.launchToday(request, prepared: preparedForNext);
    expect(startResult, isA<QuizLaunchStarted>());
    final started = (startResult as QuizLaunchStarted).session;
    expect(started.questions.length, greaterThanOrEqualTo(2));

    final controller =
        harness.providerContainer.read(quizControllerProvider.notifier);
    await controller.resumeToday(examId: selectedExamId);
    debugPrintSynchronously('E09_QLP5_STAGE=prepared_next_pump_widget_start');
    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: harness.providerContainer,
        child: MaterialApp(
          theme: buildLightTheme(),
          home: QuizPage(
            examId: selectedExamId,
            mode: QuizPageMode.practice,
          ),
        ),
      ),
    );
    debugPrintSynchronously('E09_QLP5_STAGE=prepared_next_pump_widget_done');
    await _pumpUntil(
      tester,
      () {
        final state = harness.providerContainer.read(quizControllerProvider);
        return state is QuizRunning &&
            state.questionShownAt != null &&
            _hasEnabledAnswerRow();
      },
      'first answerable frame for prepared Next fixture',
    );

    final state0 =
        harness.providerContainer.read(quizControllerProvider) as QuizRunning;
    final answer = state0.session.currentQuestion.choices.first;
    await controller.answer(chosenChoiceId: answer.id);
    await tester.pump();
    await _pumpUntilFinder(
      tester,
      find.text('Next'),
      'Next after first answer',
    );

    final timingsCallback = collector.recordFrameTimings;
    WidgetsBinding.instance.addTimingsCallback(timingsCallback);
    addTearDown(
      () => WidgetsBinding.instance.removeTimingsCallback(timingsCallback),
    );

    for (var i = 0; i < _samples; i++) {
      await controller.goTo(0);
      await tester.pump();
      await _pumpUntilFinder(tester, find.text('Next'), 'replayed Next');

      final watch = Stopwatch()..start();
      await tester.tap(find.text('Next'));
      await tester.pump();
      await _pumpUntil(
        tester,
        () {
          final state = harness.providerContainer.read(quizControllerProvider);
          return state is QuizRunning &&
              state.session.currentIndex == 1 &&
              state.questionShownAt != null &&
              _hasEnabledAnswerRow();
        },
        'prepared Next answerable frame',
      );
      watch.stop();
      collector.recordObservation(
        Qlp5Metric.preparedNext,
        watch.elapsed,
        temperature: Qlp5RunTemperature.warm,
      );
    }
    await tester.pump(const Duration(milliseconds: 100));
    await Future<void>.delayed(const Duration(milliseconds: 100));

    final summaries = <Qlp5MetricSummary>[
      collector.summary(
        Qlp5Metric.firstRecommendation,
        temperature: Qlp5RunTemperature.cold,
      ),
      collector.summary(
        Qlp5Metric.unchangedRecommendationFrame,
        temperature: Qlp5RunTemperature.warm,
      ),
      collector.summary(
        Qlp5Metric.warmStart,
        temperature: Qlp5RunTemperature.warm,
      ),
      collector.summary(
        Qlp5Metric.resume5,
        temperature: Qlp5RunTemperature.warm,
      ),
      collector.summary(
        Qlp5Metric.resume10,
        temperature: Qlp5RunTemperature.warm,
      ),
      collector.summary(
        Qlp5Metric.resume20,
        temperature: Qlp5RunTemperature.warm,
      ),
      collector.summary(
        Qlp5Metric.preparedNext,
        temperature: Qlp5RunTemperature.warm,
      ),
    ];
    for (final summary in summaries) {
      expect(summary.hasOrdinarySampleMinimum, isTrue);
    }

    final output = <String, Object?>{
      'acceptance': false,
      'purpose': 'qlp5_physical_core_ordinary_measurement',
      'source_sha': '13938943f447956af43d2de7e1f9999eb2418aee',
      'format_version': install.identity.formatVersion,
      'release_sequence': install.identity.releaseSequence,
      'payload_sha256': install.identity.payloadSha256,
      'manifest_sha256': install.identity.manifestSha256,
      'signature_sha256': install.identity.signatureSha256,
      'exam_id': selectedExamId,
      'question_pool_count': rows.length,
      'metrics': <Object?>[for (final s in summaries) s.toJson()],
      'query_counts': queryWindows,
      'phase_samples': <Object?>[
        for (final sample in collector.phaseSamples) sample.toJson(),
      ],
      'frames': collector.frameSummary.toJson(),
    };
    binding.reportData = output;
    // ignore: avoid_print -- structured local E09 physical evidence.
    print('E09_QLP5_CORE_JSON=${jsonEncode(output)}');
  });
}

Future<void> _resetDisposableState(ReleaseHarness harness) async {
  final db = harness.appDatabase;
  final rows = await db.customSelect(
    '''SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ''',
  ).get();
  await db.customStatement('PRAGMA foreign_keys = OFF');
  try {
    for (final row in rows) {
      final name = row.read<String>('name').replaceAll('"', '""');
      await db.customStatement('DELETE FROM "$name"');
    }
  } finally {
    await db.customStatement('PRAGMA foreign_keys = ON');
  }
}

Future<void> _pumpUntilFinder(
  WidgetTester tester,
  Finder finder,
  String label,
) =>
    _pumpUntil(
      tester,
      () => finder.evaluate().isNotEmpty,
      label,
    );

Future<void> _pumpUntil(
  WidgetTester tester,
  bool Function() predicate,
  String label,
) async {
  _throwPendingFlutterException(tester, label);
  final deadline = DateTime.now().add(const Duration(seconds: 8));
  while (!predicate()) {
    if (DateTime.now().isAfter(deadline)) {
      fail('Timed out waiting for $label.');
    }
    await tester.pump(const Duration(milliseconds: 10));
    _throwPendingFlutterException(tester, label);
  }
  _throwPendingFlutterException(tester, label);
}

void _throwPendingFlutterException(WidgetTester tester, String stage) {
  final error = tester.takeException();
  if (error == null) return;
  final payload = jsonEncode(<String, Object?>{
    'stage': stage,
    'error': error.toString(),
    'runtime_type': error.runtimeType.toString(),
  });
  // ignore: avoid_print -- structured local E09 physical diagnostic.
  print('E09_QLP5_FRAMEWORK_EXCEPTION=$payload');
  fail('Flutter framework exception during $stage: $error');
}

bool _hasEnabledAnswerRow() => find
    .byWidgetPredicate(
      (widget) => widget is AnswerRow && widget.onTap != null,
      description: 'enabled AnswerRow',
    )
    .evaluate()
    .isNotEmpty;
