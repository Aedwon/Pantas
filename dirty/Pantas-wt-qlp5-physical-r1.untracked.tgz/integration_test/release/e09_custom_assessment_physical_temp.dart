import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/core/auth/auth_state.dart';
import 'package:pantas/core/auth/providers.dart';
import 'package:pantas/core/content/bundle/protected_content_installer.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/content/security/content_package_verifier.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:pantas/core/storage/storage.dart';
import 'package:pantas/core/storage/track_scope.dart';
import 'package:pantas/core/ui/components/answer_row.dart';
import 'package:pantas/core/ui/theme/app_theme.dart';
import 'package:pantas/features/assessment/presentation/assessment_page.dart';
import 'package:pantas/features/assessment/presentation/assessment_results_page.dart';
import 'package:pantas/features/paywall/paywall.dart';
import 'package:pantas/features/quiz/application/quiz_providers.dart';

import 'support/release_harness.dart';

const _keyId = 'content-bootstrap-v1';
const _keyB64 = String.fromEnvironment('PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64');

Future<Uint8List> _load(String path) async {
  final data = await rootBundle.load(path);
  return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
}

ContentBootstrapKeyEntry? _bootstrap(String keyId) {
  if (keyId != _keyId || _keyB64.isEmpty) return null;
  final bytes = base64Decode(_keyB64);
  if (bytes.length != 32) return null;
  return ContentBootstrapKeyEntry(
    keyId: _keyId,
    keyBytes: Uint8List.fromList(bytes),
    sequenceWindow: const ContentSequenceWindow(minReleaseSequence: 1),
  );
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('E09 custom assessment physical end to end', (tester) async {
    await ensureProtectedContentInstalled(
      verifier: const BundledContentPackageVerifier(
        loadAssetBytes: _load,
        signingKeyLookup: ContentSigningKeys.lookupEntry,
        bootstrapKeyLookup: _bootstrap,
      ),
    );

    var contentQueries = 0;
    final harness = ReleaseHarness(
      additionalOverrides: <Override>[
        authStateProvider.overrideWith(
          (_) => Stream.value(
            const AuthState.anonymous(uid: 'e09-assessment-physical'),
          ),
        ),
        entitlementProvider.overrideWith(
          (_) => Stream.value(const Entitlement.free()),
        ),
        contentRepositoryProvider.overrideWith(
          (ref) => ContentRepository(
            ref.watch(contentDatabaseProvider),
            onQuery: () => contentQueries += 1,
          ),
        ),
      ],
    );
    await harness.openDatabases();
    addTearDown(harness.dispose);

    final content = harness.providerContainer.read(contentRepositoryProvider);
    final corpus = await corpusTopics(content);
    final counts = await content.activeQuestionCountsByTopics(
      [for (final topic in corpus) topic.id],
    );
    final selectedTopics =
        corpus.where((topic) => (counts[topic.id] ?? 0) >= 3).take(7).toList();
    expect(selectedTopics, hasLength(7));

    final examId = await harness.providerContainer
        .read(customTrackRepositoryProvider)
        .create(
      name: 'E09 Verify',
      includedTopicIds: {for (final topic in selectedTopics) topic.id},
    );

    final prefs =
        harness.providerContainer.read(appPreferencesRepositoryProvider);
    await prefs.setPassedAgeGate(value: true);
    await prefs.setSelectedExamId(examId);
    await prefs.setCompletedOnboarding(value: true);

    final router = GoRouter(
      initialLocation: '/assessment/$examId',
      routes: [
        GoRoute(
          path: '/assessment/:examId',
          builder: (_, state) =>
              AssessmentPage(examId: state.pathParameters['examId']!),
          routes: [
            GoRoute(
              path: 'results',
              builder: (_, state) => AssessmentResultsPage(
                examId: state.pathParameters['examId']!,
              ),
            ),
          ],
        ),
        GoRoute(
          path: '/study',
          builder: (_, __) => const Scaffold(
            body: Center(child: Text('E09 Study Landing')),
          ),
        ),
        GoRoute(
          path: '/quiz',
          builder: (_, __) => const Scaffold(
            body: Center(child: Text('E09 Quiz Landing')),
          ),
        ),
      ],
    );
    addTearDown(router.dispose);

    final revisionBefore =
        harness.providerContainer.read(quizSessionPanelRevisionProvider);
    contentQueries = 0;
    final loadWatch = Stopwatch()..start();
    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: harness.providerContainer,
        child: MaterialApp.router(
          theme: buildLightTheme(),
          routerConfig: router,
        ),
      ),
    );
    await tester.pump();
    await _pumpUntil(
      tester,
      () => _enabledAnswers().isNotEmpty,
      'first assessment answer',
    );
    loadWatch.stop();
    final startupQueries = contentQueries;

    var answered = 0;
    while (find.text('Your results').evaluate().isEmpty) {
      final answers = _enabledAnswers();
      expect(answers, isNotEmpty);
      await tester.tap(answers.first);
      answered += 1;
      await tester.pump();
      await _pumpUntil(
        tester,
        () =>
            find.text('Your results').evaluate().isNotEmpty ||
            _enabledAnswers().isNotEmpty,
        'next assessment frame or results',
      );
      expect(answered, lessThanOrEqualTo(35));
    }

    await tester.pumpAndSettle();
    expect(answered, 21);
    expect(find.text('Your E09 Verify profile'), findsOneWidget);
    expect(find.text('Topic breakdown'), findsOneWidget);
    expect(find.text('Focus areas'), findsOneWidget);
    expect(find.text('Start studying'), findsOneWidget);
    for (final topic in selectedTopics) {
      expect(
        find.text(topic.name),
        findsWidgets,
        reason: 'Result row missing for ${topic.name}',
      );
    }

    final revisionAfter =
        harness.providerContainer.read(quizSessionPanelRevisionProvider);
    expect(revisionAfter, revisionBefore + 1);
    expect(
      await harness.providerContainer
          .read(assessmentRepositoryProvider)
          .hasCompletedForExam(examId),
      isTrue,
    );

    await tester.ensureVisible(find.text('Start studying'));
    await tester.tap(find.text('Start studying'));
    await tester.pumpAndSettle();
    expect(find.text('E09 Study Landing'), findsOneWidget);

    final evidence = <String, Object>{
      'kind': 'e09_custom_assessment_physical',
      'questions': answered,
      'topics': selectedTopics.length,
      'first_answerable_ms': loadWatch.elapsedMilliseconds,
      'startup_content_queries': startupQueries,
      'results_rows_verified': selectedTopics.length,
      'start_studying_navigation': true,
      'quiz_revision_delta': revisionAfter - revisionBefore,
    };
    // ignore: avoid_print -- structured local E09 physical evidence.
    print('E09_ASSESSMENT_PHYSICAL_JSON=${jsonEncode(evidence)}');
  });
}

Iterable<Finder> _enabledAnswers() sync* {
  final finder = find.byWidgetPredicate(
    (widget) => widget is AnswerRow && widget.onTap != null,
    description: 'enabled assessment AnswerRow',
  );
  for (final element in finder.evaluate()) {
    yield find.byElementPredicate((candidate) => candidate == element);
  }
}

Future<void> _pumpUntil(
  WidgetTester tester,
  bool Function() predicate,
  String label,
) async {
  final deadline = DateTime.now().add(const Duration(seconds: 15));
  while (!predicate()) {
    if (DateTime.now().isAfter(deadline)) {
      fail('Timed out waiting for $label.');
    }
    await tester.pump(const Duration(milliseconds: 20));
  }
}
