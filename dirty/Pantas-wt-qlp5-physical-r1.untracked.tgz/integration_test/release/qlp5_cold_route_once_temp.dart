import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/app/flavor.dart';
import 'package:pantas/core/auth/auth_state.dart';
import 'package:pantas/core/auth/providers.dart';
import 'package:pantas/core/content/bundle/protected_content_installer.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';
import 'package:pantas/core/content/security/content_package_verifier.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';
import 'package:pantas/core/storage/data/repos/assessment_repository.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:pantas/core/storage/data/repos/quiz_nudge_repository.dart';
import 'package:pantas/core/storage/storage.dart';
import 'package:pantas/core/ui/components/answer_row.dart';
import 'package:pantas/features/paywall/paywall.dart';
import 'package:pantas/features/quiz/application/quiz_performance_probe.dart';
import 'package:pantas/features/quiz/application/quiz_providers.dart';
import 'package:pantas/features/quiz/domain/models/quiz_ordering.dart';
import 'package:pantas/features/quiz/domain/models/quiz_preferences.dart';
import 'package:pantas/features/quiz/presentation/quiz_controller.dart';

import 'support/qlp5_performance_collector.dart';
import 'support/release_harness.dart';

const _keyId = 'content-bootstrap-v1';
const _keyB64 = String.fromEnvironment('PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64');
final _fixedNow = DateTime(2026, 9, 15, 14);

Future<Uint8List> _load(String path) async {
  final data = await rootBundle.load(path);
  return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
}

ContentBootstrapKeyEntry? _bootstrap(String keyId) {
  if (keyId != _keyId || _keyB64.isEmpty) return null;
  final bytes = base64Decode(_keyB64);
  if (bytes.length != 32) return null;
  return ContentBootstrapKeyEntry(
    keyId: _keyId,
    keyBytes: Uint8List.fromList(bytes),
    sequenceWindow: const ContentSequenceWindow(minReleaseSequence: 1),
  );
}

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('E09 QLP5 one cold physical route', (tester) async {
    final install = await ensureProtectedContentInstalled(
      verifier: const BundledContentPackageVerifier(
        loadAssetBytes: _load,
        signingKeyLookup: ContentSigningKeys.lookupEntry,
        bootstrapKeyLookup: _bootstrap,
      ),
    );
    final collector = Qlp5PerformanceCollector();
    var queries = 0;
    final harness = ReleaseHarness(
      additionalOverrides: <Override>[
        authStateProvider.overrideWith(
          (_) => Stream.value(
            const AuthState.anonymous(uid: 'qlp5-physical'),
          ),
        ),
        entitlementProvider.overrideWith(
          (_) => Stream.value(const Entitlement.free()),
        ),
        nowProvider.overrideWithValue(() => _fixedNow),
        quizPerformanceProbeProvider.overrideWithValue(
          QuizPerformanceProbe.recording(collector.recordPhaseSample),
        ),
        contentRepositoryProvider.overrideWith(
          (ref) => ContentRepository(
            ref.watch(contentDatabaseProvider),
            onQuery: () => queries += 1,
          ),
        ),
      ],
    );
    await harness.openDatabases();
    addTearDown(harness.dispose);
    await _resetDisposableState(harness);

    final content = harness.providerContainer.read(contentRepositoryProvider);
    final exams = await content.listExams();
    String? examId;
    var richest = -1;
    for (final exam in exams.where((exam) => !exam.isCustom)) {
      final rows = await content.selectionRowsByExam(exam.id);
      final label = (exam.name + ' ' + exam.shortName).toUpperCase();
      if (label.contains('UPCAT') && rows.length >= 20) {
        examId = exam.id;
        break;
      }
      if (rows.length > richest) {
        richest = rows.length;
        examId = exam.id;
      }
    }
    expect(examId, isNotNull);
    final selectedExamId = examId!;
    final topics = await content.topicsByExam(selectedExamId);

    final prefs =
        harness.providerContainer.read(appPreferencesRepositoryProvider);
    await prefs.setPassedAgeGate(value: true);
    await prefs.setSelectedExamId(selectedExamId);
    await prefs.setCompletedOnboarding(value: true);
    await harness.providerContainer
        .read(assessmentRepositoryProvider)
        .saveResult(
      selectedExamId,
      _fixedNow,
      <TopicScore>[
        for (final topic in topics)
          TopicScore(topicId: topic.id, correct: 1, total: 1),
      ],
    );
    await QuizNudgeRepository(harness.appDatabase).markDismissed();
    await harness.providerContainer
        .read(quizPreferencesRepositoryProvider)
        .save(
          QuizPreferences(
            sessionLength: 20,
            ordering: QuizOrdering.blocked,
            newCardCap: 20,
          ),
        );
    await harness.providerContainer
        .read(quizSessionRepositoryProvider)
        .quitAllOpen(
          userId: quizLocalUserId,
          examId: selectedExamId,
          quitAt: _fixedNow,
        );

    final timingsCallback = collector.recordFrameTimings;
    WidgetsBinding.instance.addTimingsCallback(timingsCallback);
    addTearDown(
      () => WidgetsBinding.instance.removeTimingsCallback(timingsCallback),
    );

    await harness.pumpProductionApp(tester, flavor: Flavor.staging);
    await tester.pumpAndSettle();

    queries = 0;
    final recommendationWatch = Stopwatch()..start();
    await tester.tap(find.text('Quiz').first);
    await tester.pump();
    await _pumpUntilFinder(
      tester,
      find.text("Today's session"),
      'Today session panel',
    );
    await _pumpUntilFinder(tester, find.text('Start'), 'Today Start');
    recommendationWatch.stop();
    collector.recordObservation(
      Qlp5Metric.firstRecommendation,
      recommendationWatch.elapsed,
      temperature: Qlp5RunTemperature.cold,
    );
    final recommendationQueries = queries;

    final startFeedbackWatch = Stopwatch()..start();
    final launchWatch = Stopwatch()..start();
    await tester.tap(find.text('Start'));
    await tester.pump();
    await _pumpUntil(
      tester,
      () => harness.providerContainer.read(quizControllerProvider) is! QuizIdle,
      'Start feedback',
    );
    startFeedbackWatch.stop();
    collector.recordObservation(
      Qlp5Metric.startFeedback,
      startFeedbackWatch.elapsed,
      temperature: Qlp5RunTemperature.cold,
    );

    await _pumpUntil(
      tester,
      () {
        final state = harness.providerContainer.read(quizControllerProvider);
        return state is QuizRunning &&
            state.questionShownAt != null &&
            _hasEnabledAnswerRow();
      },
      'first complete answerable frame',
    );
    launchWatch.stop();
    collector
      ..recordObservation(
        Qlp5Metric.coldDailyRoute,
        launchWatch.elapsed,
        temperature: Qlp5RunTemperature.cold,
      )
      ..recordObservation(
        Qlp5Metric.firstAnswerable,
        launchWatch.elapsed,
        temperature: Qlp5RunTemperature.cold,
      )
      ..recordObservation(
        Qlp5Metric.launchToAnswerable,
        launchWatch.elapsed,
        temperature: Qlp5RunTemperature.cold,
      );
    await tester.pump(const Duration(milliseconds: 100));

    final output = <String, Object?>{
      'acceptance': false,
      'purpose': 'qlp5_physical_single_cold_route',
      'source_sha': '9f7a2da1af9a516144067995beec5d2ed7a45f78',
      'release_sequence': install.identity.releaseSequence,
      'payload_sha256': install.identity.payloadSha256,
      'manifest_sha256': install.identity.manifestSha256,
      'signature_sha256': install.identity.signatureSha256,
      'exam_id': selectedExamId,
      'recommendation_queries': recommendationQueries,
      'metrics': <Object?>[
        collector
            .summary(
              Qlp5Metric.firstRecommendation,
              temperature: Qlp5RunTemperature.cold,
            )
            .toJson(),
        collector
            .summary(
              Qlp5Metric.startFeedback,
              temperature: Qlp5RunTemperature.cold,
            )
            .toJson(),
        collector
            .summary(
              Qlp5Metric.coldDailyRoute,
              temperature: Qlp5RunTemperature.cold,
            )
            .toJson(),
        collector
            .summary(
              Qlp5Metric.firstAnswerable,
              temperature: Qlp5RunTemperature.cold,
            )
            .toJson(),
        collector
            .summary(
              Qlp5Metric.launchToAnswerable,
              temperature: Qlp5RunTemperature.cold,
            )
            .toJson(),
      ],
      'phase_samples': <Object?>[
        for (final sample in collector.phaseSamples) sample.toJson(),
      ],
      'frames': collector.frameSummary.toJson(),
    };
    binding.reportData = output;
    print('E09_QLP5_COLD_JSON=' + jsonEncode(output));
  });
}

Future<void> _resetDisposableState(ReleaseHarness harness) async {
  final db = harness.appDatabase;
  final rows = await db
      .customSelect(
        "SELECT name FROM sqlite_master "
        "WHERE type = 'table' AND name NOT LIKE 'sqlite_%'",
      )
      .get();
  await db.customStatement('PRAGMA foreign_keys = OFF');
  try {
    for (final row in rows) {
      final name = row.read<String>('name').replaceAll('"', '""');
      await db.customStatement('DELETE FROM "' + name + '"');
    }
  } finally {
    await db.customStatement('PRAGMA foreign_keys = ON');
  }
}

Future<void> _pumpUntilFinder(
  WidgetTester tester,
  Finder finder,
  String label,
) =>
    _pumpUntil(tester, () => finder.evaluate().isNotEmpty, label);

Future<void> _pumpUntil(
  WidgetTester tester,
  bool Function() predicate,
  String label,
) async {
  final deadline = DateTime.now().add(const Duration(seconds: 8));
  while (!predicate()) {
    if (DateTime.now().isAfter(deadline)) {
      fail('Timed out waiting for $label.');
    }
    await tester.pump(const Duration(milliseconds: 10));
  }
}

bool _hasEnabledAnswerRow() => find
    .byWidgetPredicate(
      (widget) => widget is AnswerRow && widget.onTap != null,
      description: 'enabled AnswerRow',
    )
    .evaluate()
    .isNotEmpty;
