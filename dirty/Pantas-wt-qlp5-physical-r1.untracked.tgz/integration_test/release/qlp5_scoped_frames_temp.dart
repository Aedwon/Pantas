import 'dart:convert';
import 'dart:ui' show FrameTiming;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/app/flavor.dart';
import 'package:pantas/core/auth/auth_state.dart';
import 'package:pantas/core/auth/providers.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/storage/data/repos/assessment_repository.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:pantas/core/storage/data/repos/quiz_nudge_repository.dart';
import 'package:pantas/core/storage/storage.dart';
import 'package:pantas/core/ui/components/answer_row.dart';
import 'package:pantas/core/ui/components/qlp5_probe_temp.dart';
import 'package:pantas/features/paywall/paywall.dart';
import 'package:pantas/features/quiz/application/quiz_performance_probe.dart';
import 'package:pantas/features/quiz/application/quiz_providers.dart';
import 'package:pantas/features/quiz/domain/models/quiz_ordering.dart';
import 'package:pantas/features/quiz/domain/models/quiz_preferences.dart';
import 'package:pantas/features/quiz/presentation/quiz_controller.dart';

import 'support/qlp5_performance_collector.dart';
import 'support/release_harness.dart';

final _fixedNow = DateTime(2026, 9, 15, 14);

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('E09 QLP5 tightly scoped physical frame windows', (tester) async {
    final phaseCollector = Qlp5PerformanceCollector();
    var queries = 0;
    final harness = ReleaseHarness(
      additionalOverrides: <Override>[
        authStateProvider.overrideWith(
          (_) => Stream.value(
            const AuthState.anonymous(uid: 'qlp5-physical'),
          ),
        ),
        entitlementProvider.overrideWith(
          (_) => Stream.value(const Entitlement.free()),
        ),
        nowProvider.overrideWithValue(() => _fixedNow),
        quizPerformanceProbeProvider.overrideWithValue(
          QuizPerformanceProbe.recording(phaseCollector.recordPhaseSample),
        ),
        contentRepositoryProvider.overrideWith(
          (ref) => ContentRepository(
            ref.watch(contentDatabaseProvider),
            onQuery: () => queries += 1,
          ),
        ),
      ],
    );
    await harness.openDatabases();
    addTearDown(harness.dispose);
    await _resetDisposableState(harness);

    final content = harness.providerContainer.read(contentRepositoryProvider);
    final exams = await content.listExams();
    String? examId;
    var richest = -1;
    for (final exam in exams.where((exam) => !exam.isCustom)) {
      final rows = await content.selectionRowsByExam(exam.id);
      final label = (exam.name + ' ' + exam.shortName).toUpperCase();
      if (label.contains('UPCAT') && rows.length >= 20) {
        examId = exam.id;
        break;
      }
      if (rows.length > richest) {
        richest = rows.length;
        examId = exam.id;
      }
    }
    expect(examId, isNotNull);
    final selectedExamId = examId!;
    final topics = await content.topicsByExam(selectedExamId);

    final prefs =
        harness.providerContainer.read(appPreferencesRepositoryProvider);
    await prefs.setPassedAgeGate(value: true);
    await prefs.setSelectedExamId(selectedExamId);
    await prefs.setCompletedOnboarding(value: true);
    await harness.providerContainer
        .read(assessmentRepositoryProvider)
        .saveResult(
      selectedExamId,
      _fixedNow,
      <TopicScore>[
        for (final topic in topics)
          TopicScore(topicId: topic.id, correct: 1, total: 1),
      ],
    );
    await QuizNudgeRepository(harness.appDatabase).markDismissed();
    await harness.providerContainer
        .read(quizPreferencesRepositoryProvider)
        .save(
          QuizPreferences(
            sessionLength: 20,
            ordering: QuizOrdering.blocked,
            newCardCap: 20,
          ),
        );
    await harness.providerContainer
        .read(quizSessionRepositoryProvider)
        .quitAllOpen(
          userId: quizLocalUserId,
          examId: selectedExamId,
          quitAt: _fixedNow,
        );

    await harness.pumpProductionApp(tester, flavor: Flavor.staging);
    await tester.pumpAndSettle();

    final routeBuildUs = <int>[];
    final routeRasterUs = <int>[];
    void routeFrames(List<FrameTiming> timings) {
      for (final timing in timings) {
        routeBuildUs.add(timing.buildDuration.inMicroseconds);
        routeRasterUs.add(timing.rasterDuration.inMicroseconds);
      }
    }

    queries = 0;
    WidgetsBinding.instance.addTimingsCallback(routeFrames);
    final recommendationWatch = Stopwatch()..start();
    await tester.tap(find.text('Quiz').first);
    await tester.pump();
    await _pumpUntilFinder(
      tester,
      find.text("Today's session"),
      'Today session panel',
    );
    final startFinder = find.text('Start');
    await _pumpUntilFinder(tester, startFinder, 'Today Start');
    recommendationWatch.stop();
    final recommendationQueries = queries;

    await tester.ensureVisible(startFinder);
    await tester.pumpAndSettle();
    final hitTestableStart = startFinder.hitTestable();
    await _pumpUntilFinder(
      tester,
      hitTestableStart,
      'hit-testable Today Start',
    );

    final startFeedbackWatch = Stopwatch()..start();
    final launchWatch = Stopwatch()..start();
    await tester.tap(hitTestableStart);
    await tester.pump();
    await _pumpUntil(
      tester,
      () => harness.providerContainer.read(quizControllerProvider) is! QuizIdle,
      'Start feedback',
    );
    startFeedbackWatch.stop();

    await _pumpUntil(
      tester,
      () {
        final state = harness.providerContainer.read(quizControllerProvider);
        return state is QuizRunning &&
            state.questionShownAt != null &&
            _hasEnabledAnswerRow();
      },
      'first complete answerable frame',
    );
    launchWatch.stop();
    await _waitForFrameTimings(
      routeBuildUs,
      routeRasterUs,
      'Quiz route frame timings',
    );
    WidgetsBinding.instance.removeTimingsCallback(routeFrames);

    final controller =
        harness.providerContainer.read(quizControllerProvider.notifier);
    final running =
        harness.providerContainer.read(quizControllerProvider) as QuizRunning;
    final answer = running.session.currentQuestion.choices.first;
    await controller.answer(chosenChoiceId: answer.id);
    await tester.pump();
    await _pumpUntilFinder(tester, find.text('Next'), 'prepared Next control');

    final diagnosticProbeUs = <String, List<int>>{};
    qlp5ProbeSink = (label, microseconds) {
      diagnosticProbeUs.putIfAbsent(label, () => <int>[]).add(microseconds);
    };
    final nextBuildUs = <int>[];
    final nextRasterUs = <int>[];
    void nextFrames(List<FrameTiming> timings) {
      for (final timing in timings) {
        nextBuildUs.add(timing.buildDuration.inMicroseconds);
        nextRasterUs.add(timing.rasterDuration.inMicroseconds);
      }
    }

    WidgetsBinding.instance.addTimingsCallback(nextFrames);
    final nextWatch = Stopwatch()..start();
    await tester.tap(find.text('Next'));
    await tester.pump();
    await _pumpUntil(
      tester,
      () {
        final state = harness.providerContainer.read(quizControllerProvider);
        return state is QuizRunning &&
            state.session.currentIndex == 1 &&
            state.questionShownAt != null &&
            _hasEnabledAnswerRow();
      },
      'prepared Next answerable frame',
    );
    nextWatch.stop();
    await _waitForFrameTimings(
      nextBuildUs,
      nextRasterUs,
      'Prepared Next frame timings',
    );
    WidgetsBinding.instance.removeTimingsCallback(nextFrames);
    qlp5ProbeSink = null;

    expect(routeBuildUs, isNotEmpty);
    expect(routeRasterUs, isNotEmpty);
    expect(nextBuildUs, isNotEmpty);
    expect(nextRasterUs, isNotEmpty);

    final output = <String, Object?>{
      'acceptance': false,
      'purpose': 'qlp5_physical_scoped_frame_measurement',
      'diagnostic_variant': 'hierarchical-layout-probe-r6-footer-slot',
      'diagnostic_hashes': {
        'lib/core/ui/components/answer_row.dart':
            'a1aafbc0a7049a369ba9283db6b2928b6245962e23f4a5e859f05c20d80a0a42',
        'lib/core/ui/components/portable_text_renderer.dart':
            '6825eb8670d04704fe981d1e50dba63184bfa155c672bf231f93f1bb7ca2f0a2',
        'lib/core/ui/components/qlp5_probe_temp.dart':
            '6292ecdb812e9d5268c903699b1c20488eb1720bf2b0df61a4a1e85bd2c3f033',
        'lib/core/ui/components/question_card.dart':
            'f4684a234dd224ced049995f1b916b7a952bebc914967bf77da31c0ffb31dd51',
      },
      'source_sha': '8cbaaeea4515a624d30943eff0d8b3c841e984d9',
      'harness_revision': 'start-hit-explicit-adb-r6-hier-layout',
      'repair_quiz_page_sha256':
          'd81762fc1f2da2d8518fcc6c26e816f0624553249f4f9f86caf94e7b7e930ec0',
      'repair_quiz_controller_sha256':
          'cf8c500fcbfbbdbf55a7c4975b34d68b551a335f770a45ab513368065473bc54',
      'release_sequence': 2,
      'exam_id': selectedExamId,
      'recommendation_queries': recommendationQueries,
      'first_recommendation_us': recommendationWatch.elapsedMicroseconds,
      'start_feedback_us': startFeedbackWatch.elapsedMicroseconds,
      'launch_to_answerable_us': launchWatch.elapsedMicroseconds,
      'prepared_next_us': nextWatch.elapsedMicroseconds,
      'route_build_us': routeBuildUs,
      'route_raster_us': routeRasterUs,
      'next_build_us': nextBuildUs,
      'next_raster_us': nextRasterUs,
      'diagnostic_probe_us': diagnosticProbeUs,
      'phase_samples': <Object?>[
        for (final sample in phaseCollector.phaseSamples) sample.toJson(),
      ],
    };
    binding.reportData = output;
    print('E09_QLP5_SCOPED_FRAMES=' + jsonEncode(output));
  });
}

Future<void> _waitForFrameTimings(
  List<int> buildUs,
  List<int> rasterUs,
  String label,
) async {
  final deadline = DateTime.now().add(const Duration(seconds: 2));
  while (buildUs.isEmpty || rasterUs.isEmpty) {
    if (DateTime.now().isAfter(deadline)) {
      fail('Timed out waiting for $label callback.');
    }
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}

Future<void> _resetDisposableState(ReleaseHarness harness) async {
  final db = harness.appDatabase;
  final rows = await db
      .customSelect(
        "SELECT name FROM sqlite_master "
        "WHERE type = 'table' AND name NOT LIKE 'sqlite_%'",
      )
      .get();
  await db.customStatement('PRAGMA foreign_keys = OFF');
  try {
    for (final row in rows) {
      final name = row.read<String>('name').replaceAll('"', '""');
      await db.customStatement('DELETE FROM "' + name + '"');
    }
  } finally {
    await db.customStatement('PRAGMA foreign_keys = ON');
  }
}

Future<void> _pumpUntilFinder(
  WidgetTester tester,
  Finder finder,
  String label,
) =>
    _pumpUntil(tester, () => finder.evaluate().isNotEmpty, label);

Future<void> _pumpUntil(
  WidgetTester tester,
  bool Function() predicate,
  String label,
) async {
  final deadline = DateTime.now().add(const Duration(seconds: 8));
  while (!predicate()) {
    if (DateTime.now().isAfter(deadline)) {
      fail('Timed out waiting for $label.');
    }
    await tester.pump(const Duration(milliseconds: 10));
  }
}

bool _hasEnabledAnswerRow() => find
    .byWidgetPredicate(
      (widget) => widget is AnswerRow && widget.onTap != null,
      description: 'enabled AnswerRow',
    )
    .evaluate()
    .isNotEmpty;
