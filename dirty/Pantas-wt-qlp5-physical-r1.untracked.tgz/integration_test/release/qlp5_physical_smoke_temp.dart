import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/core/content/bundle/protected_content_installer.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/content/security/content_package_manifest.dart';
import 'package:pantas/core/content/security/content_package_verifier.dart';
import 'package:pantas/core/content/security/content_signing_keys.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'support/release_harness.dart';

const _keyId = 'content-bootstrap-v1';
const _keyB64 = String.fromEnvironment('PANTAS_CONTENT_BOOTSTRAP_KEY_V1_B64');

Future<Uint8List> _load(String path) async {
  final data = await rootBundle.load(path);
  return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
}

ContentBootstrapKeyEntry? _bootstrap(String keyId) {
  if (keyId != _keyId || _keyB64.isEmpty) return null;
  final bytes = base64Decode(_keyB64);
  if (bytes.length != 32) return null;
  return ContentBootstrapKeyEntry(
    keyId: _keyId,
    keyBytes: Uint8List.fromList(bytes),
    sequenceWindow: const ContentSequenceWindow(minReleaseSequence: 1),
  );
}

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('QLP5 disposable package opens real protected content',
      (tester) async {
    final result = await ensureProtectedContentInstalled(
      verifier: const BundledContentPackageVerifier(
        loadAssetBytes: _load,
        signingKeyLookup: ContentSigningKeys.lookupEntry,
        bootstrapKeyLookup: _bootstrap,
      ),
    );
    final harness = ReleaseHarness();
    await harness.openDatabases();
    addTearDown(harness.dispose);

    final repo = harness.providerContainer.read(contentRepositoryProvider);
    final exams = await repo.listExams();
    expect(exams, isNotEmpty);

    final output = <String, Object?>{
      'acceptance': false,
      'purpose': 'qlp5_disposable_real_protected_content_smoke',
      'install_decision': result.decision.name,
      'exam_count': exams.length,
      'format_version': result.identity.formatVersion,
      'release_sequence': result.identity.releaseSequence,
      'payload_sha256': result.identity.payloadSha256,
      'manifest_sha256': result.identity.manifestSha256,
      'signature_sha256': result.identity.signatureSha256,
    };
    binding.reportData = output;
    print('E09_QLP5_DISPOSABLE_SMOKE=' + jsonEncode(output));
  });
}
