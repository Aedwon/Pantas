import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:pantas/core/auth/auth_state.dart';
import 'package:pantas/core/auth/providers.dart';
import 'package:pantas/core/content/content.dart';
import 'package:pantas/core/storage/data/repos/content_repository.dart';
import 'package:pantas/core/storage/storage.dart';
import 'package:pantas/features/paywall/paywall.dart';
import 'package:pantas/features/quiz/application/quiz_performance_probe.dart';
import 'package:pantas/features/quiz/application/quiz_providers.dart';
import 'package:pantas/features/quiz/application/today_quiz_preparer.dart';

import 'support/qlp5_performance_collector.dart';
import 'support/release_harness.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('E09 QLP5 staging read-only physical profile smoke',
      (tester) async {
    final collector = Qlp5PerformanceCollector();
    var queries = 0;
    final harness = ReleaseHarness(
      additionalOverrides: <Override>[
        authStateProvider.overrideWith(
          (_) => Stream.value(
            const AuthState.anonymous(uid: 'qlp5-readonly'),
          ),
        ),
        entitlementProvider.overrideWith(
          (_) => Stream.value(const Entitlement.free()),
        ),
        quizPerformanceProbeProvider.overrideWithValue(
          QuizPerformanceProbe.recording(collector.recordPhaseSample),
        ),
        contentRepositoryProvider.overrideWith(
          (ref) => ContentRepository(
            ref.watch(contentDatabaseProvider),
            onQuery: () => queries += 1,
          ),
        ),
      ],
    );
    await harness.openDatabases();
    addTearDown(harness.dispose);

    final prefs =
        harness.providerContainer.read(appPreferencesRepositoryProvider);
    final selected = await prefs.selectedExamId();
    expect(selected, isNotNull);

    final content = harness.providerContainer.read(contentRepositoryProvider);
    final exams = await content.listExams();
    final exam = exams.firstWhere((candidate) => candidate.id == selected);

    queries = 0;
    final request = QuizPreparationRequest(
      userId: quizLocalUserId,
      examId: exam.id,
    );
    final watch = Stopwatch()..start();
    final prepared =
        await harness.providerContainer.read(todayQuizPreparerProvider).prepare(
              request,
            );
    watch.stop();

    expect(prepared.plan.questions, isNotEmpty);
    final output = <String, Object>{
      'acceptance': false,
      'purpose': 'physical_profile_staging_readonly_probe_smoke',
      'exam': exam.shortName,
      'prepare_elapsed_us': watch.elapsedMicroseconds,
      'question_count': prepared.plan.questions.length,
      'query_count': queries,
      'phase_samples': <Object>[
        for (final sample in collector.phaseSamples) sample.toJson(),
      ],
    };
    print('E09_QLP5_STAGING_READONLY_SMOKE_JSON=' + jsonEncode(output));
  });
}
