import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

typedef Qlp5ProbeSink = void Function(String label, int microseconds);

Qlp5ProbeSink? qlp5ProbeSink;

class Qlp5LayoutProbe extends SingleChildRenderObjectWidget {
  const Qlp5LayoutProbe({
    required this.label,
    required super.child,
    super.key,
  });

  final String label;

  @override
  RenderObject createRenderObject(BuildContext context) =>
      Qlp5LayoutProbeRenderObject(label);

  @override
  void updateRenderObject(
    BuildContext context,
    covariant Qlp5LayoutProbeRenderObject renderObject,
  ) {
    renderObject.label = label;
  }
}

class Qlp5LayoutProbeRenderObject extends RenderProxyBox {
  Qlp5LayoutProbeRenderObject(this.label);

  String label;

  @override
  void performLayout() {
    final sink = qlp5ProbeSink;
    if (sink == null) {
      super.performLayout();
      return;
    }
    final watch = Stopwatch()..start();
    super.performLayout();
    watch.stop();
    sink(label, watch.elapsedMicroseconds);
  }
}
