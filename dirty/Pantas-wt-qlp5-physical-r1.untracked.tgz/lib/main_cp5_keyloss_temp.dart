import 'dart:io';

import 'package:flutter/widgets.dart';
import 'package:pantas/app/bootstrap.dart';
import 'package:pantas/app/flavor.dart';
import 'package:pantas/core/content/security/content_key_store.dart';
import 'package:path_provider/path_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final root = await getApplicationSupportDirectory();
  final marker = File('${root.path}/cp5-keyloss-once.marker');
  if (!marker.existsSync()) {
    await marker.writeAsString('armed', flush: true);
    await ContentKeyStore().delete();
  }
  await bootstrap(Flavor.staging);
}
