import 'dart:io';

import 'package:flutter_driver/flutter_driver.dart';

Future<void> main() async {
  final driver = await FlutterDriver.connect();
  try {
    final raw = await driver.requestData(
      null,
      timeout: const Duration(minutes: 20),
    );
    print('E09_RAW_INTEGRATION_RESPONSE=$raw');
  } finally {
    await driver.close();
  }
  exit(0);
}
